# LoveWall

#### 自我介绍
LoveWall，顾名思义，其实就是表白墙。
一生那么长，只为遇见你。
#### 特色功能
1. 点赞
2. 发评论
3. 发弹幕
4. 多校区
5. 分享页
6. 涉证、涉H、暴力、违禁物等名词进行检测
7. wait Update。
#### 默认后台
后台入口/admin  账号admin  密码521wall.cn
#### 官方信息
1.官方演示地址：http://lw2.demo.kres.cn  OR https://521wall.cn

2.官方BUG提交反馈：https://pro.kres.cn/form/index/bugsubmit

3.官方邮箱反馈地址：admin@jishuzy.com  OR admin@mail.catni.cn

4.官方完整更新下载地址：https://gitee.com/ncnet/10001

5.官方增量更新下载地址：https://pro.kres.cn/update/get?appid=10002

6.官方wiki文档：https://wiki.521wal.cn
此版本将会不断更新！
#### 软件架构
1.前端框架：LayUI 2.4、Jquery

2.后端框架：ThinkPHP 5.0.24

3.图标素材：阿里巴巴

4.API调用：天气网、Ncnet官方
#### 测试环境
1.PHP     ：7.2.11

2.Mysql   : 5.7

3.Apache  ：2.4.35
#### 安装教程

1. 下载完整源码
2. 上传源码到服务器并设置运行目录为 /public
3. 使用伪静态规则ThinkPHP（此处不提供）
4. 导入根目录下的 import.sql 文件，并配置application/database.php文件下的连接信息
5. 首次使用请配置发信邮箱 \extend\PHPMailer\SendEmail.php ,否则校区审核无法通知
6. 大功告成，开始尽情使用吧！

#### 参与贡献
1. Csdn 社区、手册 (滑稽.jpg)
2. 文案：猫腻
3. 开发：橘子(Cheng)、Ncnet
4. 测试：猫腻、久念
